
jQuery(document).ready(function($) {
	
	jQuery(window).scroll(function() {
		if (jQuery(this).scrollTop() > 1){  
			jQuery('.page-title').addClass("sticky");
		}
		else{
			jQuery('.page-title').removeClass("sticky");
		}
	});

});
/*
$(document).ready(function() {
	
	$(window).scroll(function() {
		if ($(this).scrollTop() > 1){  
			$('.page-title').addClass("sticky");
		}
		else{
			$('.page-title').removeClass("sticky");
		}
	});

});
*/

